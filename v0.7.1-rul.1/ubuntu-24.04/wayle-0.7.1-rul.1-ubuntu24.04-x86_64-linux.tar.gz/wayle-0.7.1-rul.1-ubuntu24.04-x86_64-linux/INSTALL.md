# Wayle for Ubuntu 24.04, x86-64

Combines hover drawers and independent Wi-Fi adapter controls. Both applications
are included. Check downloads with `sha256sum -c SHA256SUMS`.

Install:

    sudo apt install ./wayle_0.7.1-rul.1+ubuntu24.04_amd64.deb
    /usr/bin/wayle --version

The package supplies private GTK 4.16.13 and gtk4-layer-shell 1.0.4 libraries
under /usr/lib/wayle. The system GTK installation is preserved; no PPA is needed.
The command launchers select the bundled GTK schemas and libraries.

If your user service points to an older copy, set ExecStart to `/usr/bin/wayle shell`,
then run `systemctl --user daemon-reload` and `systemctl --user restart wayle`.
Check `command -v wayle` and `command -v wayle-settings` for older user launchers.
Your configuration is preserved.

The archive is relocatable: keep libexec/, lib/, and share/ beside the `wayle`
and `wayle-settings` launchers. Use those launchers, rather than the ELF files
inside libexec/. The .deb is recommended for resolving system dependencies.

Build details are in BUILD-INFO.txt. License notices and the GTK/protocol source
archives are included. The dynamically linked private libraries can be replaced
with compatible rebuilt versions.

Per-adapter switches control NetworkManager management, not hardware power;
their state resets when NetworkManager restarts. Multi-adapter hardware testing
remains outstanding. This is a fork prerelease.
