#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y --no-install-recommends libdrm-dev libgirepository1.0-dev python3-jinja2 python3-docutils gettext libjpeg-dev libpng-dev libtiff-dev libfontconfig-dev libxrandr-dev libxi-dev libxdamage-dev libxcomposite-dev libxfixes-dev libxcursor-dev libxinerama-dev libepoxy-dev libegl1-mesa-dev libxkbcommon-dev sassc
meson setup /work/protocols-build /work/protocols-src --prefix=/opt/wayle-runtime -Dtests=false
meson install -C /work/protocols-build
export PKG_CONFIG_PATH=/opt/wayle-runtime/share/pkgconfig:/opt/wayle-runtime/lib/pkgconfig
meson setup /work/gtk-build /work/gtk416-src --prefix=/opt/wayle-runtime --libdir=lib --buildtype=release --wrap-mode=nofallback -Dmedia-gstreamer=disabled -Dvulkan=disabled -Dprint-cups=disabled -Dprint-cpdb=disabled -Dintrospection=disabled -Ddocumentation=false -Dman-pages=false -Dbuild-demos=false -Dbuild-examples=false -Dbuild-tests=false -Dbuild-testsuite=false -Df16c=disabled
meson compile -C /work/gtk-build -j 4
meson install -C /work/gtk-build
mkdir -p /work/private-runtime/lib /work/private-runtime/share
cp -a /opt/wayle-runtime/lib/libgtk-4.so* /work/private-runtime/lib/
cp -a /opt/wayle-runtime/share/glib-2.0 /work/private-runtime/share/
glib-compile-schemas /work/private-runtime/share/glib-2.0/schemas
cp -a /opt/wayle-layer-shell/lib/libgtk4-layer-shell.so* /work/private-runtime/lib/
for lib in /work/private-runtime/lib/*.so.*; do
    if [[ ! -L "$lib" ]]; then patchelf --set-rpath '$ORIGIN' "$lib"; fi
done
printf 'GTK runtime built\n'
