This fork release combines the hover-drawers and wifi-adapters branches.

- Drawer groups expand when hovering anywhere on that monitor's bar.
- Active night-light and caffeine widgets stay visible; inactive widgets can collapse completely.
- The network dropdown lists Wi-Fi adapters with independent switches. Disabling the built-in interface allows another managed adapter to supply the network list.
- The existing global Wi-Fi switch still controls the system-wide radio.

The archive includes both `wayle` and `wayle-settings`, icons, completions, licenses, and build information. The `.deb` includes the applications, icons, completions, and systemd user service. Check downloads with `sha256sum -c SHA256SUMS`.

These are **x86-64 builds for Debian 13 or compatible newer systems**, built on Debian 13. They are dynamically linked; older distributions need a build for their own libraries. No ARM binary is included.

Install the Debian package:

```sh
sudo apt install ./wayle_0.7.1-rul.1_amd64.deb
/usr/bin/wayle --version
```

If an existing user launcher or service points to an older copy, ensure it selects the new binary. A user service override can use:

```ini
[Service]
ExecStart=
ExecStart=/usr/bin/wayle shell
Environment=PATH=/usr/bin:/bin:%h/.local/bin:%h/bin
```

After changing the override, run `systemctl --user daemon-reload` and `systemctl --user restart wayle`. The settings application is `/usr/bin/wayle-settings`. This package does not replace personal configuration.

Enable drawer groups with `drawer = true` in the bar layout. Stock Wayle 0.7.1 accepts this configuration but renders ordinary groups.

Per-adapter switches control NetworkManager management, not hardware power. Their state resets when NetworkManager restarts. Multiple-adapter selection is covered by unit tests; two-adapter hardware testing and visual verification of the new network controls remain outstanding. Treat this as a prerelease.
